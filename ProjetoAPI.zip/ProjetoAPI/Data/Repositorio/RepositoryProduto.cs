﻿using Data.Entidades;
using Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Data.Repositorio
{
    public class RepositoryProduto : RepositoryGenerics<Produto>, IProduto
    {
        public Task<List<Produto>> ListagemCustomizada()
        {
            throw new NotImplementedException();
        }
    }
}
